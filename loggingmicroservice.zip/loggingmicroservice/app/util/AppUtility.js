'use strict';
const fs = require("fs").promises;


class AppUtility {
 
  constructor() {
   
  }

  async writeData(data) {
      try{
        console.log("log req data from console.");
        await fs.writeFile("log.txt",
            "console.log('Hello world with promisify and async/await!');");  
        console.info("file created successfully with promisify and async/await!");
      }catch(err){
        console.error(err);
      }
   
  
  }

  
}




module.exports = AppUtility;
