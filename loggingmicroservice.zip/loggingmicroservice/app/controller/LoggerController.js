'use strict';
const express = require('express');
const app = express();
const logging = require('@sap/logging');
const AppUtility = require('../util/AppUtility');

const apputilObj = new AppUtility();

class LoggerController {
 
  constructor(reqdata) {
    this.request = reqdata;
    const appContext = logging.createAppContext({req:this.request});
    app.use(logging.middleware({ appContext: appContext, logNetwork: true }));
  }

  async  postLogData() {
      try{
        console.log("log req data from console.");
        //var logger = req.loggingContext.getLogger('/Application/Network');
        //var tracer = req.loggingContext.getTracer(__filename);
    
          var logger = appContext.createLogContext().getLogger('/api/v1/logdata/');
          console.log("logger obj after  creating log contex...",JSON.stringify(logger));
        //var tracer = appContext.createLogContext().getTracer(__filename);
        //logger.info('Successful login of user %s - ',  new Date());
    
        //logger.error('Retrieving demo greeting ...');
        // tracer.info('Processing GET request to /demo');
    
        let logPacket = "";
        await apputilObj.writeData(logPacket);
        return true;
      }catch (err){
       console.log('error  in postLog Data ',err);
      }
    
  }


}




module.exports = LoggerController;
