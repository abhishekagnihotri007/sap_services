/*
 * Author: abhishek
 * Date: 15-07-2020
 * Description: The response.js file will use to send the final API response, in a specific formate. 
 * use this file in any js file by using 
 * var result = require('../resources/response');
 * 
 */

module.exports = { 
			success:"",
			message:"",
			ExceptionMessage:"",
			data:"",
			status:"200"
};
