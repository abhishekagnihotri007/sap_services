const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const cors = require('cors');
const url = require('url');
const app = express();

dotenv.config();

const port = process.env.PORT || 3040;
const approot = '/api/v1/';

var routes = require('./routes/api/v1/indexRouter');
// enable CORS
app.use(cors());
// parse application/json
app.use(bodyParser.json());
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/', routes);


// If no route is matched by now, it must be a 404
app.use(function(req, res, next) {
    console.log(req.body);
    console.log({status:404,message:`NO ROUTE IS MATCHED: ${req.originalUrl} ,method ${req.method}`});
    res.status(404).end({status:404,message:`NO ROUTE IS MATCHED: ${req.originalUrl} ,method ${req.method}`});

	//next(err);
});
app.listen(port, () => {
  console.log('Server started on: ' , port);
});
