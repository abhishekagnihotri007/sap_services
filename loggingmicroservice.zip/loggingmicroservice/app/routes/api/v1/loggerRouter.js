
const LoggerController = require('../../../controller/LoggerController');

//const postLogData 
module.exports = {
     postLogData:  async function (req,res){
                    try{

                    const loogectrlrObj = new LoggerController(req,res);
                    var postLogResult = await loogectrlrObj.postLogData();

                    res.send('log data successfully!');
                    }catch(ex){
                    console.log(`error occured in logging message...: ${JSON.stringify(ex)}`);
                    }
                
                
        }
}



